﻿#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <easyx.h>
#include<thread>
#include<atomic>

#define ROW 10 //定义行列的变量
#define COL 10
#define MineNum 10 //雷的数量
#define ImgSize 40 //图片的尺寸
#define TimerHeight 40 //定时器区域的高度

int mineImgIndex; // 引入选择的雷图片索引
int maxflag = MineNum; //限制可插旗数小于等于雷数

std::atomic<bool> isRunning(true); //原子变量，用于控制线程的运行状态
std::atomic<int> elapsedTime(0); //原子变量，用于存储经过的时间
std::thread timerThread; // 定时器线程

// 定时器函数
void timer()
{
	while (isRunning)
	{
		std::this_thread::sleep_for(std::chrono::seconds(1)); // 每秒更新一次
		elapsedTime++;
	}
}

// 在屏幕上显示计时器
void displayTimer()
{
	char timeStr[50];
	sprintf_s(timeStr, "%03d", elapsedTime.load());
	settextstyle(40, 0, "Consolas");
	outtextxy(0, 0, timeStr); // 在棋盘左上方显示时间
}

void displayflagCount()
{
	char flagCountStr[32];
	sprintf_s(flagCountStr, "剩余旗数：%02d", maxflag);
	settextstyle(40, 0, "Consolas");
	outtextxy(100, 0, flagCountStr); // 在屏幕上显示剩余旗子数
}

//定义图片资源
IMAGE imgs[17];
void loadResource(){
	for (int i = 0; i < 17; i++){
		char imgPath[50] = { 0 };
		sprintf_s(imgPath, "./images/%d.jpg", i);
		loadimage(&imgs[i], imgPath, ImgSize, ImgSize);
		//putimage(i * ImgSize, 0, imgs + i);
	}
}

int selectMineImage() //选择雷的函数
{
	int options[3] = {9, 15, 16}; // 可选的雷图片编号
	int selected = options[0]; // 默认雷图片编号为9
	// 创建一个简单的选择界面
	settextstyle(30, 0, "Consolas");
	outtextxy(100, 100, "请选择雷的图片：");
	for (int i = 0; i < 3; ++i) // 假设9,15,16为可选雷图片
	{
		char label[16];
		sprintf_s(label, " ", options[i]);
		putimage(100 + i * (ImgSize + 30), 160, &imgs[options[i]]);
		outtextxy(100 + i * (ImgSize + 30), 160 + ImgSize + 5, label);
	}
	// 鼠标选择
	while (true)
	{
		ExMessage msg;
		if (peekmessage(&msg, EX_MOUSE))
		{
			if (msg.message == WM_LBUTTONDOWN)
			{
				for (int i = 0; i < 3; ++i)
				{
					int x1 = 100 + i * (ImgSize + 30);
					int y1 = 160;
					int x2 = x1 + ImgSize;
					int y2 = y1 + ImgSize;
					if (msg.x >= x1 && msg.x <= x2 && msg.y >= y1 && msg.y <= y2)
						return options[i];
				}
			}
		}
	}
}

// 函数声明
void show(int map[][COL]);
void init(int map[][COL]);
void draw(int map[][COL]);
void mouseMsg(ExMessage* msg, int map[][COL]);
void boomBlank(int map[][COL], int row, int col);
int judge(int map[][COL],int row,int col);

int main(){
	//创建窗口
	 initgraph(COL * ImgSize, ROW * ImgSize + TimerHeight, EX_SHOWCONSOLE);
	 loadResource(); //加载图片资源
	 mineImgIndex = selectMineImage(); // 选择雷的图片
	 cleardevice(); // 清屏
	 // 初始化显示计时器
	 displayTimer();
	//扫雷地图
	int map[ROW][COL] = { 0 }; // 初始化数组以避免未定义行为
	init(map); // 初始化地图
	draw(map); // 绘制地图
	while (1){
		ExMessage msg;
		if (peekmessage(&msg, EX_MOUSE))
		{
			if (msg.message == WM_LBUTTONDOWN)
			{
				break; //点击鼠标左键退出循环
			}
		}
	}
	// 启动定时器线程
	std::thread timerThread(timer);
	//游戏主循环
	while (true)
	{
		// 显示计时器并归零
		displayTimer();
		displayflagCount(); // 显示剩余旗子数
		//处理消息
		ExMessage msg;
		while (peekmessage(&msg, EX_MOUSE))
		{
			switch (msg.message)
			{
			case WM_LBUTTONDOWN:	//鼠标左键和右键点击
			case WM_RBUTTONDOWN:
				
				mouseMsg(&msg, map); //处理鼠标点击事件
				// 如果定时器未启动，则启动定时器
				if (!isRunning)
				{
					isRunning = true;
					timerThread = std::thread(timer); // 启动定时器线程
				}
				int ret = judge(map,(msg.y / ImgSize)-1,msg.x / ImgSize); //点击之后判断
				if (ret == -1)
				{
					isRunning = false; // 停止计时器
					if (timerThread.joinable())
						timerThread.join(); // 等待定时器线程结束
					for (int i = 0; i < ROW; i++)
					{
						for (int k = 0; k < COL; k++)
						{
							if (map[i][k] == -1) //雷格子
							{
								map[i][k] -= 2; //爆炸格
								draw(map); //显示雷
							}
							else if (map[i][k] == 19)
							{
								map[i][k] -= 20; //埋雷的格子
								putimage(k * ImgSize, (i + 1) * ImgSize, &imgs[mineImgIndex]); //显示雷
							}
							else if (map[i][k] == 39) //标对
							{
								map[i][k] -= 40; //标对的雷
								putimage(k * ImgSize, (i + 1) * ImgSize, &imgs[mineImgIndex]); //显示雷
							}
							else if (map[i][k] >= 40) //标错
							{
								map[i][k] = -2; //标错的雷
								draw(map); //显示雷
							}
						}
					}
					int select = MessageBox(GetHWnd(), "Game Over\n是否再来一把", "提示", MB_OKCANCEL);
					if(select == IDOK) //再来一把
					{
						maxflag = MineNum; //重置可插旗数
						elapsedTime = 0; // 重置计时器
						isRunning = false;
						if (timerThread.joinable())
							timerThread.join(); // 确保线程已停止
						//重新初始化
						init(map);
					}
					else //退出游戏
					{
						exit(0);
					}
				}
				else if(ret == 1)
				{
					isRunning = false; // 停止计时器
					if (timerThread.joinable())
						timerThread.join(); // 等待定时器线程结束
					for (int i = 0; i < ROW; i++)
					{
						for (int k = 0; k < COL; k++)
						{
							if (map[i][k] == 19)
							{
								map[i][k] -= 20; //埋雷的格子
								putimage(k * ImgSize, (i + 1) * ImgSize, &imgs[mineImgIndex]); //显示雷
							}
							else if (map[i][k] == 39)
							{
								map[i][k] -= 40; //标对的格子
								putimage(k * ImgSize, (i + 1) * ImgSize, &imgs[mineImgIndex]); //显示雷
							}
						}
					}
					int select = MessageBox(GetHWnd(), "You Win\n还要再来一把吗", "提示", MB_OKCANCEL);
					if (select == IDOK) //再来一把
					{
						maxflag = MineNum; //重置可插旗数
						elapsedTime = 0; // 重置计时器
						isRunning = false;
						if (timerThread.joinable())
							timerThread.join(); // 确保线程已停止
						//重新初始化
						init(map);
					}
					else //退出游戏
					{
						exit(0);
					}
				}
				else
				{
					//继续游戏
				}
				system("cls"); //清屏
				printf("judge = %d\n", ret);
				break;
			}
		}
		draw(map);
	}
	// 停止计时器线程
	isRunning = false;
	timerThread.join();
	
	return 0;
}

void show(int map[][COL])
{
	for (int i = 0; i < ROW; i++){
		for (int k = 0; k < COL; k++){
			printf("%2d ", map[i][k]);
		}
		printf("\n");
	}
}
//初始化数据
void init(int map[][COL]){
	loadResource();
	//设置随机数种子
	srand((unsigned)time(NULL));
	//把map全部初始化为0
	memset(map, 0, sizeof(int)*ROW*COL); //清空数组
	//随机设置十个雷 用-1表示
	for (int i = 0; i < MineNum; ){
		//数组的有效下标[0,9]
		int r = rand() % ROW; //随机行
		int c = rand() % COL; //随机列
		if (map[r][c] == 0) {
			map[r][c] = -1;
			//只有执行了这里的代码，才成功设置了雷 -1
			i++; //成功设置雷的数量加1
		}
	}
	//把以雷为中心的九宫格数据都加1，雷除外
	for (int i = 0; i < ROW; i++)
	{
		for (int k = 0; k < COL; k++)
		{
			//找到雷，并遍历雷所在的九宫格
			if (map[i][k] == -1) //如果是雷
			{
				for (int r = i - 1; r <= i + 1; r++){
					for (int c = k - 1; c <= k + 1; c++){
						//对周围的数据加1，防止越界
						if (r >= 0 && r < ROW && c >= 0 && c < COL)
						{
							if (map[r][c] != -1)
							{
								map[r][c]++;
							}
						}
					}
				}
			}
		}
	}

	//加密格子
	for (int i = 0; i < ROW; i++)
	{
		for (int k = 0; k < COL; k++)
		{
			map[i][k] += 20; //加密
		}
	}
}
//绘制
void draw(int map[][COL]){
	//贴图，根据map里面的数据，贴对应的图片
	for (int i = 0; i < ROW; i++)
	{
		for (int k = 0; k < COL; k++)
		{
			if (map[i][k] >= 0 && map[i][k] <= 8) //[0,8]
			{
				putimage(k * ImgSize, (i+1) * ImgSize, &imgs[map[i][k]]);
			}
			else if (map[i][k] == -1) //如果是雷
			{
				putimage(k * ImgSize, (i + 1) * ImgSize, &imgs[mineImgIndex]); //雷
			}
			else if (map[i][k] >= 19 && map[i][k] <= 28) //标记范围
			{
				putimage(k * ImgSize, (i + 1) * ImgSize, &imgs[10]); //盖住图像，加密
			}
			else if (map[i][k] >= 39)
			{
				putimage(k * ImgSize, (i + 1) * ImgSize, &imgs[11]); //打开的格子
			}
			else if (map[i][k] == -2)
			{
				putimage(k * ImgSize, (i + 1) * ImgSize, &imgs[12]); //标错的格子
			}
			else if (map[i][k] == -3)
			{
				putimage(k * ImgSize, (i + 1) * ImgSize, &imgs[13]); //爆炸格
			}
		}
	}
}
//鼠标操作数据
void mouseMsg(ExMessage* msg, int map[][COL])
{
	//先根据鼠标点击的坐标求出对应的数组的下标
	int r = msg->y / ImgSize; //行
	int c = msg->x / ImgSize; //列
	r--;
	//判断点击的是左键还是右键
	if (msg->message == WM_LBUTTONDOWN) //左键打开格子
	{
		//没有打开的时候可以打开格子
		if (map[r][c] >= 19 && map[r][c] <= 28)
		{
			map[r][c] -= 20; //打开格子
			boomBlank(map, r, c); //检测一下是不是空白格子，是则炸开
		}
	}
	else if (msg->message == WM_RBUTTONDOWN) //右键标记格子
	{
		//没有打开的时候可以标记格子
		if (map[r][c] >= 19 && map[r][c] <= 28 && maxflag != 0)
		{
			map[r][c] += 20; //加密
			maxflag = maxflag - 1;
		}
		else if (map[r][c] >= 39)
		{
			map[r][c] -= 20; //将标记过的格子加密
			maxflag = maxflag + 1;
		}
	}
}
//点击空白格子，连环爆开周围的所有空白格子还有数字  row col 是当前点击的格子
void boomBlank(int map[][COL],int row,int col){
	//判断row col位置是不是空白格子
	if (map[row][col] == 0) //如果是空白格子
	{
		//把周围的格子都打开
		for (int r = row - 1; r <= row + 1; r++)
		{
			for (int c = col - 1; c <= col + 1; c++)
			{
				if (r >= 0 && r < ROW && c >= 0 && c < COL) //没越界
				{
					if (map[r][c] >= 19 && map[r][c] <= 28) //如果是加密的格子
					{
						map[r][c] -= 20; //打开格子
						boomBlank(map, r, c); //递归炸开
					}
				}
			}
		}
	}
	else if (map[row][col] >= 19 && map[row][col] <= 28) //如果是数字格子
	{
		map[row][col] -= 20; //打开格子
	}
}
//游戏结束条件 输了返回-1，没结束返回0，赢了返回1
int judge(int map[][COL],int row ,int col)
{
	//点到了雷，结束，输了
	if(map[row][col] == -1)
	{ 
		return -1;
	}
	//点完了格子，结束，赢了 点开了100 - 10 = 90个格子
	int cnt = 0; //计数器
	int lei = 0; //正确排雷数;
	for (int i = 0; i < ROW; i++)
	{
		for (int k = 0; k < COL; k++)
		{
			if (map[i][k] >= 0 && map[i][k] <= 8) //统计打开的格子的数量
			{
				cnt++;
			}
			else if (map[i][k] == 39)
			{
				lei++;
			}
		}
	}
	if (cnt == ROW * COL - MineNum || lei == MineNum) //如果打开的格子数量等于总格子数量减去雷的数量或着正确排出所有的雷
	{
		return 1; //赢了
	}

	return 0; //没结束
}